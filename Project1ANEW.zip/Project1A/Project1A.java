

class Project1A {
    public static void main (String[] args) {
        double quadA = 1;
        double quadB = 5;
        double quadC = 6;
        double quadAnsPlus;
        double quadAnsMinus;
        
        quadAnsPlus = (-1*quadB - Math.sqrt(quadB*quadB - 4*quadA*quadC)) / 2;
        quadAnsMinus = (-1*quadB + Math.sqrt(quadB*quadB - 4*quadA*quadC)) / 2;;
        
        System.out.println("QUADRATIC EQUATION");
        System.out.println("The Solutions For " + quadA + "x^2 + " + quadB + "x + " + quadC + " are " + quadAnsPlus +  " and " + quadAnsMinus);
        System.out.println();
        System.out.println();
        System.out.println();
        
        double slopeY1 = 0;
        double slopeY2 = 3;
        double slopeX1 = 0;
        double slopeX2 = 2;
        double slopeXAll;
        double slopeYAll;
        double slopeAll;
        
        slopeYAll = slopeY2 - slopeY1;
        slopeXAll = slopeX2 - slopeX1;
        
        slopeAll = slopeYAll/slopeXAll;
        
        System.out.println("SLOPE FORMULA");
        System.out.println("A line connecting the points (" + slopeX1 + ", " + slopeY1 + ") / (" + slopeX2 + ", " + slopeY2 + ") has a slope of " + slopeAll);
        System.out.println();
        System.out.println();
        System.out.println();
        
        double midpointY2 = 3;
        double midpointY1 = 0;
        double midpointX2 = 2;
        double midpointX1 = 0;
        double midpointXAll;
        double midpointYAll;
        
        midpointYAll = (midpointY2 + midpointY1) / 2;
        midpointXAll = (midpointX2 + midpointX1) / 2;
        
        System.out.println("MIDPOINT FORMULA");
        System.out.println("The midpoint between (" + midpointY1 + ", " + midpointX1 + ") and (" + midpointY2 + ", " + midpointX2 + ") is (" + midpointXAll + ", " + midpointYAll + ")");
        System.out.println();
        System.out.println();
        System.out.println();
        
        double sumStart = 1;
        double sumAmount = 1;
        double sumAnswer;
        
        sumAnswer = sumStart + sumStart + sumAmount + sumStart + 2 * sumAmount + sumStart + 3 * sumAmount + sumStart + 4 * sumAmount;
        
        System.out.println("SUM OF AN ARITHMETIC SERIES");
        System.out.println("The sum of the first 5 terms of an arithmetic series that starts with " + sumStart + " and increases by " + sumAmount + " is " + sumAnswer);
        System.out.println();
        System.out.println();
        System.out.println();
        
        double geoStart = 1;
        double geoAmount = 2;
        double geoAnswer;
        
        geoAnswer = geoStart * (1 - Math.pow(geoAmount, 3))/(1 - geoAmount);
        
        System.out.println("SUM OF A GEOMETRIC SERIES");
        System.out.println("The sum of the first 3 terms of a finite geometric series that starts with " + geoStart + " and increases by a rate of " + geoAmount + " is " + geoAnswer); 
        
        
        
    }
}